@echo off
setlocal
cd /d "%~dp0"
set "HUB_NODE_BIN="
set "HUB_CODEX_BIN="
for /f "delims=" %%i in ('where node.exe 2^>nul') do if not defined HUB_NODE_BIN set "HUB_NODE_BIN=%%i"
if not defined HUB_NODE_BIN if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" set "HUB_NODE_BIN=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
for /f "delims=" %%i in ('where codex.exe 2^>nul') do if not defined HUB_CODEX_BIN set "HUB_CODEX_BIN=%%i"
if not defined HUB_CODEX_BIN for /f "usebackq delims=" %%i in (`powershell.exe -NoProfile -Command "Get-ChildItem -LiteralPath ($env:LOCALAPPDATA + '\OpenAI\Codex\bin') -Filter codex.exe -Recurse -ErrorAction SilentlyContinue ^| Sort-Object LastWriteTime -Descending ^| Select-Object -First 1 -ExpandProperty FullName"`) do set "HUB_CODEX_BIN=%%i"
if not defined HUB_NODE_BIN goto no_node
if not defined HUB_CODEX_BIN goto no_codex
if "%~1"=="--locate-only" (
  echo Required runtimes found. No collection performed.
  exit /b 0
)
echo Reading local conversation titles. No AI calls or uploads.
"%HUB_NODE_BIN%" collector\probe-local.mjs
if errorlevel 1 goto failed
echo.
echo Completed. Results: private\collector\probe-result.json
echo Private titles: private\collector\local-snapshot.json
echo No scheduled task has been installed.
if not "%~1"=="--no-pause" pause
exit /b 0
:no_node
echo Node.js runtime was not found. Share this message to continue setup.
goto failed
:no_codex
echo Local Codex runtime was not found. This probe cannot collect web-only ChatGPT history.
goto failed
:failed
echo The existing Chat History Hub has not been changed.
if not "%~1"=="--no-pause" if not "%~1"=="--locate-only" pause
exit /b 1
